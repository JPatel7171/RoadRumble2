﻿using System;

internal class CarLights
{
    internal bool isBackLightOn;

    internal void OperateBackLights()
    {
        throw new NotImplementedException();
    }
}